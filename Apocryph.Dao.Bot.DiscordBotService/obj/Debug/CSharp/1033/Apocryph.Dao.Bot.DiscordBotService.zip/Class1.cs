﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Apocryph.Dao.Bot.DiscordBotService
{
	public class Class1
	{

	}
}
